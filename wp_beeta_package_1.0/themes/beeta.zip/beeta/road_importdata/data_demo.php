<?php 
$array_imports = array(
	'home1' => array(
		'image' => 'screenshot',
		'page_name' => 'Fashion Home 1',
		'is_default' => 1
	),
	'home2' => array(
		'image' => 'screenshot2',
		'page_name' => 'Fashion Home 2',
		
	),
	'home3' => array(
		'image' => 'screenshot3',
		'page_name' => 'Fashion Home 3',
		
	), 
	'cosmetic1' => array(
		'image' => 'screenshot4',
		'page_name' => 'Cosmetic Home 1',
		
	), 
	'cosmetic2' => array(
		'image' => 'screenshot5',
		'page_name' => 'Cosmetic Home 2',
		
	), 
	'cosmetic3' => array(
		'image' => 'screenshot6',
		'page_name' => 'Cosmetic Home 3',
		
	), 
	'cosmetic4' => array(
		'image' => 'screenshot7',
		'page_name' => 'Cosmetic Home 4',
		
	), 	
);
$opt_name = 'beeta_opt'; 					